import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  updatetrainee: Trainees;
  constructor(private httpService: HttpClient) { }
  public getTrainees() {
    console.log("ins service get trainees");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.get<Trainees>("http://localhost:7800/trainee/getall");
  }

  public addTrainee(addtrainee: Trainees) {
    console.log("ins service add");
    console.log(addtrainee);
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.post("http://localhost:7800/trainee/add", addtrainee,  { headers, responseType: 'text'});
  }
  
  public update(updatetrainee: Trainees) {
    this.updatetrainee = updatetrainee;
  }
  public updateMethod() {
    return this.updatetrainee;
  }
  public onUpdate(trainee: Trainees) {
    console.log("ins service update");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.put("http://localhost:7800/trainee/update", trainee,  { headers, responseType: 'text'});
  }
  delete(id: number) {
    console.log("ins service delete");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.delete("http://localhost:7800/trainee/delete" + id,  { headers, responseType: 'text'});
  }

}
export class Trainees {
  id: number;
  name: string;
  location: string;
  domain: string;
}