import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyserviceService, Trainees } from '../myservice.service';

@Component({
  selector: 'app-add-trainee',
  templateUrl: './add-trainee.component.html',
  styleUrls: ['./add-trainee.component.css']
})
export class AddTraineeComponent implements OnInit {
  message: string;

  constructor(private myservice: MyserviceService,private router: Router) { }

  ngOnInit(): void {
  }
  onSubmit(addtrainee:Trainees):any{
    console.log(addtrainee);
     this.myservice.addTrainee(addtrainee).subscribe(data => {
      this.message=data});
  }

}
